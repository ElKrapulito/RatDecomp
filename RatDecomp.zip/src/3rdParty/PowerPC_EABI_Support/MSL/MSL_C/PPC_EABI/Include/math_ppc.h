#ifndef PPC_EABI_SRC_MATH_PPC_H
#define PPC_EABI_SRC_MATH_PPC_H



#endif /* PPC_EABI_SRC_MATH_PPC_H */