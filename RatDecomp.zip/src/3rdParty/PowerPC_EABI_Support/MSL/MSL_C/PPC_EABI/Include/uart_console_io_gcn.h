#ifndef PPC_EABI_SRC_UART_CONSOLE_IO_GCN_H
#define PPC_EABI_SRC_UART_CONSOLE_IO_GCN_H

#include "ansi_files.h"

#endif /* PPC_EABI_SRC_UART_CONSOLE_IO_GCN_H */